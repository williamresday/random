import os
import subprocess
import sys
import customtkinter as ctk
import urllib.request
import zipfile
import threading
from tkinter import messagebox

VERSION_URL = "https://raw.githubusercontent.com/williamresday/random/refs/heads/main/version.txt"
UPDATE_URL = "https://raw.githubusercontent.com/williamresday/random/refs/heads/main/aeq manager"

class AEQInstaller(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("AEQ Installer")
        self.geometry("600x400")
        self.resizable(False, False)
        
        # Tabs setup
        self.tabview = ctk.CTkTabview(self)
        self.tabview.pack(expand=True, fill="both")

        self.install_tab = self.tabview.add("Install")
        self.update_tab = self.tabview.add("Update")
        self.help_tab = self.tabview.add("Help")
        
        self.create_install_tab()
        self.create_update_tab()
        self.create_help_tab()

        self.local_version = None  # Version of the currently installed app
        self.remote_version = None  # Latest version available online

    # Install Tab
    def create_install_tab(self):
        self.install_frame = ctk.CTkFrame(self.install_tab)
        self.install_frame.pack(expand=True, fill="both", padx=20, pady=20)

        self.label = ctk.CTkLabel(self.install_frame, text="Install libraries from GitHub:")
        self.label.pack(pady=10)

        # Read-only textbox for displaying installation logs
        self.textbox = ctk.CTkTextbox(self.install_frame, width=500, height=200)
        self.textbox.pack(pady=10)
        self.textbox.configure(state="disabled")

        # Progress bar (hidden by default)
        self.progress_bar = ctk.CTkProgressBar(self.install_frame, width=500)
        self.progress_bar.set(0)
        self.progress_bar.pack(pady=10)
        self.progress_bar.pack_forget()  # Initially hidden

        # Install button
        self.install_button = ctk.CTkButton(self.install_frame, text="Install", command=self.start_install_libraries)
        self.install_button.pack(pady=10)

    def start_install_libraries(self):
        # Hide install button and show progress bar
        self.install_button.pack_forget()
        self.progress_bar.pack()  # Show progress bar

        threading.Thread(target=self.install_libraries, daemon=True).start()

    def log_message(self, message):
        self.textbox.configure(state="normal")
        self.textbox.insert("end", f"{message}\n")
        self.textbox.configure(state="disabled")
        self.textbox.see("end")

    def install_libraries(self):
        requirements_url = "https://raw.githubusercontent.com/williamresday/random/refs/heads/main/install.txt"
        local_file = "install.txt"

        try:
            self.progress_bar.set(0)
            self.log_message("Downloading requirements...")

            # Download requirements.txt
            urllib.request.urlretrieve(requirements_url, local_file)
            self.log_message("Downloaded install.txt successfully.")

            # Install libraries
            self.log_message("Installing libraries...")

            # Run pip install command
            process = subprocess.Popen(
                [sys.executable, "-m", "pip", "install", "-r", local_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            total_lines = 0
            current_line = 0

            # First pass: count the total lines
            for line in process.stdout.readlines():
                if "Collecting" in line:  # Count only the lines that are related to package installation
                    total_lines += 1

            # Reset the process to start over for reading
            process.stdout.seek(0)

            # Second pass: process the actual installation output and update the progress
            for line in process.stdout.readlines():
                if "Collecting" in line:
                    current_line += 1
                    progress = current_line / total_lines
                    self.progress_bar.set(progress)  # Update progress bar

                    # Log the message
                    self.log_message(line.strip())

            process.stdout.close()

            # Wait for the process to complete
            process.wait()

            # Clean up
            os.remove(local_file)
            self.log_message("Installation complete. Removed install.txt.")
            self.log_message("Finished installation.")  # Added finished line

        except Exception as e:
            messagebox.showerror("Error", f"Failed to download or install libraries: {str(e)}")
        finally:
            self.progress_bar.set(1)  # Ensure progress bar is at 100%
            self.progress_bar.pack_forget()  # Hide progress bar after completion

            # Show the Install button again after the installation is complete
            self.install_button.pack(pady=10)  # Show the Install button again

    # Update Tab
    def create_update_tab(self):
        self.update_frame = ctk.CTkFrame(self.update_tab)
        self.update_frame.pack(expand=True, fill="both", padx=20, pady=20)

        self.label = ctk.CTkLabel(self.update_frame, text="Update AEQ Manager:")
        self.label.pack(pady=10)

        # Read-only textbox for displaying update logs
        self.update_textbox = ctk.CTkTextbox(self.update_frame, width=500, height=150)
        self.update_textbox.pack(pady=10)
        self.update_textbox.configure(state="disabled")

        self.update_button = ctk.CTkButton(self.update_frame, text="Check for Updates", command=self.check_for_updates)
        self.update_button.pack(pady=10)

        self.update_label = ctk.CTkLabel(self.update_frame, text="")
        self.update_label.pack(pady=10)

    def check_for_updates(self):
        threading.Thread(target=self.fetch_local_version, daemon=True).start()

    def fetch_local_version(self):
        try:
            self.update_label.configure(text="Checking for updates...")
            self.log_update_message("Checking for updates...")

            # Check for local version in "AEQ Manager/version.txt" in Documents folder
            documents_folder = os.path.expanduser("~/Documents")
            version_file_path = os.path.join(documents_folder, "AEQ Manager", "version.txt")
            
            if os.path.exists(version_file_path):
                with open(version_file_path, "r") as version_file:
                    self.local_version = version_file.read().strip()
                self.update_label.configure(text=f"Local version: {self.local_version}")
                self.log_update_message(f"Local version: {self.local_version}")
            else:
                self.local_version = "Unknown"
                self.update_label.configure(text="Local version not found, assuming 'Unknown'.")
                self.log_update_message("Local version not found, assuming 'Unknown'.")
            
            # Now proceed to fetch the remote version
            self.fetch_remote_version()
        
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch local version: {str(e)}")

    def fetch_remote_version(self):
        try:
            # Fetch the remote version
            response = urllib.request.urlopen(VERSION_URL)
            self.remote_version = response.read().decode("utf-8").strip()

            # Compare with local version
            if self.local_version != self.remote_version:
                self.update_label.configure(
                    text=f"Update available: {self.remote_version} (current: {self.local_version})"
                )
                self.log_update_message(f"Update available: {self.remote_version} (current: {self.local_version})")
                self.start_update_aeq_manager()
            else:
                self.update_label.configure(text="No updates available.")
                self.log_update_message("No updates available.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch remote version: {str(e)}")

    def start_update_aeq_manager(self):
        threading.Thread(target=self.update_aeq_manager, daemon=True).start()

    def update_aeq_manager(self):
        zip_filename = "aeq-manager.zip"

        try:
            self.update_label.configure(text="Downloading update...")
            self.log_update_message("Downloading update...")
            urllib.request.urlretrieve(UPDATE_URL, zip_filename)

            # Extract the zip file
            self.update_label.configure(text="Extracting files...")
            self.log_update_message("Extracting files...")
            with zipfile.ZipFile(zip_filename, 'r') as zip_ref:
                zip_ref.extractall("aeq-manager")

            os.remove(zip_filename)  # Remove the zip file after extraction
            self.update_label.configure(text="Update completed successfully.")
            self.log_update_message("Update completed successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update AEQ Manager: {str(e)}")

    def log_update_message(self, message):
        self.update_textbox.configure(state="normal")
        self.update_textbox.insert("end", f"{message}\n")
        self.update_textbox.configure(state="disabled")
        self.update_textbox.see("end")

    # Help Tab
    def create_help_tab(self):
        self.help_frame = ctk.CTkFrame(self.help_tab)
        self.help_frame.pack(expand=True, fill="both", padx=20, pady=20)

        help_text = (
            "AEQ Installer Help:\n\n"
            "1. Install Tab: Installs libraries from a predefined GitHub URL.\n"
            "2. Update Tab: Updates AEQ Manager using online version checking.\n"
            "3. Ensure you have an active internet connection.\n"
        )
        self.help_label = ctk.CTkLabel(self.help_frame, text=help_text, wraplength=500)
        self.help_label.pack(pady=20)

if __name__ == "__main__":
    app = AEQInstaller()
    app.mainloop()
