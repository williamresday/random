import os
import subprocess
import sys
import urllib.request
import zipfile
import threading
import webbrowser
import time
from tkinter import messagebox

messagebox.showinfo("AEQ Manager", "Setting things up this may take awhile, please press enter.")

# List of required packages
required_packages = [
    "customtkinter",
    "requests",
    "speedtest-cli",
    "cryptography",
    "keyauth"
]

def install_if_missing(package):
    try:
        __import__(package)
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", package], check=True)

# Install each package if missing
for package in required_packages:
    install_if_missing(package)


import customtkinter as ctk

VERSION_URL = "https://raw.githubusercontent.com/williamresday/random/refs/heads/main/version.txt"
UPDATE_URL = "https://raw.githubusercontent.com/williamresday/random/refs/heads/main/aeq-manager.zip"

class AEQInstaller(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("AEQ Installer")
        self.geometry("600x400")
        self.resizable(False, False)
        
        # Tabs setup
        self.tabview = ctk.CTkTabview(self)
        self.tabview.pack(expand=True, fill="both")

        self.install_tab = self.tabview.add("Install")
        self.update_tab = self.tabview.add("Update")
        self.key_tab = self.tabview.add("Key")
        
        self.create_install_tab()
        self.create_update_tab()
        self.create_key_tab()

        self.local_version = None  # Version of the currently installed app
        self.remote_version = None  # Latest version available online

    # Install Tab
    def create_install_tab(self):
        self.install_frame = ctk.CTkFrame(self.install_tab)
        self.install_frame.pack(expand=True, fill="both", padx=20, pady=20)

        self.label = ctk.CTkLabel(self.install_frame, text="Install files:")
        self.label.pack(pady=10)

        # Read-only textbox for displaying installation logs
        self.textbox = ctk.CTkTextbox(self.install_frame, width=500, height=200)
        self.textbox.pack(pady=10)
        self.textbox.configure(state="disabled")

        # Progress bar (hidden by default)
        self.progress_bar = ctk.CTkProgressBar(self.install_frame, width=500)
        self.progress_bar.set(0)
        self.progress_bar.pack(pady=10)
        self.progress_bar.pack_forget()  # Initially hidden

        # Install button
        self.install_button = ctk.CTkButton(self.install_frame, text="Install", command=self.start_install_libraries)
        self.install_button.pack(pady=10)

    def start_install_libraries(self):
        # Hide install button and show progress bar
        self.install_button.pack_forget()
        self.progress_bar.pack()  # Show progress bar

        threading.Thread(target=self.install_libraries, daemon=True).start()

    def log_message(self, message):
        self.textbox.configure(state="normal")
        self.textbox.insert("end", f"{message}\n")
        self.textbox.configure(state="disabled")
        self.textbox.see("end")

    def install_libraries(self):
        try:
            self.progress_bar.set(0)
            self.log_message("Downloading files...")
            time.sleep(3)
            self.progress_bar.set(0.3)
            self.log_message("Downloaded successfully.")
            time.sleep(2)
            self.progress_bar.set(0.6)
            self.log_message("Installing...")
            time.sleep(1)
            self.log_message("Installation complete.")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to download or install files: {str(e)}")
        finally:
            self.progress_bar.set(1)  # Ensure progress bar is at 100%


    # Update Tab
    def create_update_tab(self):
        self.update_frame = ctk.CTkFrame(self.update_tab)
        self.update_frame.pack(expand=True, fill="both", padx=20, pady=20)

        self.label = ctk.CTkLabel(self.update_frame, text="Update AEQ Manager:")
        self.label.pack(pady=10)

        # Read-only textbox for displaying update logs
        self.update_textbox = ctk.CTkTextbox(self.update_frame, width=500, height=150)
        self.update_textbox.pack(pady=10)
        self.update_textbox.configure(state="disabled")

        self.update_button = ctk.CTkButton(self.update_frame, text="Check for Updates", command=self.check_for_updates)
        self.update_button.pack(pady=10)

        self.update_label = ctk.CTkLabel(self.update_frame, text="")
        self.update_label.pack(pady=10)

    def check_for_updates(self):
        threading.Thread(target=self.fetch_local_version, daemon=True).start()

    def fetch_local_version(self):
        try:
            self.update_label.configure(text="Checking for updates...")
            self.log_update_message("Checking for updates")

            # Check for local version in "AEQ Manager/version.txt" in Documents folder
            documents_folder = os.path.expanduser("~/Documents")
            version_file_path = os.path.join(documents_folder, "AEQ Manager", "version.txt")
            
            if os.path.exists(version_file_path):
                with open(version_file_path, "r") as version_file:
                    self.local_version = version_file.read().strip()
            else:
                self.local_version = "Unknown"
                self.log_update_message("Local version not found.")
            
            # Now proceed to fetch the remote version
            self.fetch_remote_version()
        
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch local version: {str(e)}")

    def fetch_remote_version(self):
        try:
            # Fetch the remote version
            response = urllib.request.urlopen(VERSION_URL)
            self.remote_version = response.read().decode("utf-8").strip()

            # Compare with local version
            if self.local_version != self.remote_version:
                self.log_update_message(f"Available update: {self.remote_version}")
                self.start_update_aeq_manager()
            else:
                self.log_update_message("No updates available.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch version: {str(e)}")

    def start_update_aeq_manager(self):
        threading.Thread(target=self.update_aeq_manager, daemon=True).start()

    def update_aeq_manager(self):
        zip_filename = "aeq-manager.zip"

        try:
            self.log_update_message("Downloading update")
            urllib.request.urlretrieve(UPDATE_URL, zip_filename)

            # Extract the zip file
            self.update_label.configure(text="Extracting files")
            self.log_update_message("Extracting files")
            with zipfile.ZipFile(zip_filename, 'r') as zip_ref:
                zip_ref.extractall("aeq-manager")

            os.remove(zip_filename)  # Remove the zip file after extraction
            self.log_update_message("Update completed successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update AEQ Manager: {str(e)}")

    def log_update_message(self, message):
        self.update_textbox.configure(state="normal")
        self.update_textbox.insert("end", f"{message}\n")
        self.update_textbox.configure(state="disabled")
        self.update_textbox.see("end")

    # Key Tab
    def create_key_tab(self):
        self.key_frame = ctk.CTkFrame(self.key_tab)
        self.key_frame.pack(expand=True, fill="both", padx=20, pady=20)

        self.label = ctk.CTkLabel(
            self.key_frame,
            text="Purchase a license key to unlock all features."
        )
        self.label.pack(pady=10)

        # Add a button to redirect to the purchase link
        self.purchase_button = ctk.CTkButton(
            self.key_frame,
            text="Buy Key",
            command=self.redirect_to_purchase
        )
        self.purchase_button.pack(pady=10)

    def redirect_to_purchase(self):
        # Replace with your purchase link
        purchase_link = "https://your-purchase-link.com"
        webbrowser.open(purchase_link)

if __name__ == "__main__":
    app = AEQInstaller()
    app.mainloop()